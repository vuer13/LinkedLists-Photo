#include "block.h"
#include <cmath>
#include <iostream>

int Block::Height() const {
	/* your code here */
	return 0;
}

int Block::Width() const {
	/* your code here */
	return 0;
}

void Block::Render(PNG &im, int x) const {
	/* your code here */

	
}

void Block::Build(PNG &im, int x, int width) {
	/* your code here */

	
}
